import os


def generate_directories() -> None: ...
